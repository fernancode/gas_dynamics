__author__ = 'Fernando A de la Fuente'
__copyright__ = 'Copyright 2020'
__credits__ = ['Fernando A de la Fuente', 'Teddy White']
__license__ = ' '
__version__ = '0.8'
__maintainer__ = 'Fernando A de la Fuente'
__email__ = 'FernandoAdelaFuente@gmail.com'
__status__ = 'Growing'


print('# ' + '=' * 78)
print('Author: ' + __author__)
print('Copyright: ' + __copyright__)
print('Credits: ' + ', '.join(__credits__))
print('License: ' + __license__)
print('Version: ' + __version__)
print('Maintainer: ' + __maintainer__)
print('Email: ' + __email__)
print('Status: ' + __status__)
print('# ' + '=' * 78)